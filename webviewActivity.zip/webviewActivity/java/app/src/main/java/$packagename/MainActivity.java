package $packagename;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.graphics.Color;
import android.app.NotificationChannel;
import android.media.RingtoneManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.app.AlertDialog;

import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.View;
import android.view.ViewTreeObserver;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.os.Handler;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.security.Permission;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import androidx.annotation.RequiresApi;

public class MainActivity extends Activity {
	WebView webView;
	ProgressBar progressBar;
	SwipeRefreshLayout swipeRefreshLayout;
	String URL = "http://localhost:8080";
	Notification notification;
	NotificationManager nm;

	private String[] PERMISSIONS;
	private static final String PERMISSION_ACCESS_FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
	private static final int PERMISSION_REQ_CODE = 100;
	private static final String CHANNEL_ID = "MY";
	private static final int NOTIFICATION_ID = 111;

	final long[] vibe = { 500 };
	final Uri notificationsound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		progressBar = (ProgressBar) findViewById(R.id.progressBar);
		webView = (WebView) findViewById(R.id.webView);
		swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe);
		NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

		webView.getSettings().setJavaScriptEnabled(true);

		webView.addJavascriptInterface(new WebAppInterface(this), "WebAppInterface");

		webView.getSettings().setAllowFileAccess(true);

		webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);

		webView.getSettings().setLoadWithOverviewMode(true);

		webView.getSettings().setUseWideViewPort(true);

		webView.getSettings().setAllowContentAccess(true);

		webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

		webView.getSettings().setBuiltInZoomControls(false);

		webView.getSettings().setLoadsImagesAutomatically(true);

		webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);

		webView.getSettings().setDomStorageEnabled(true);

		webView.getSettings().setGeolocationEnabled(true);

		

		PERMISSIONS = new String[] {

				Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION,
				Manifest.permission.CAMERA

		};
		
			//swipeToRefress
		swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				swipeRefreshLayout.setRefreshing(true);
				new Handler().postDelayed(new Runnable() {
					@Override
					public void run() {
						swipeRefreshLayout.setRefreshing(false);
						webView.reload();
					}
				}, 2600);
			}
		});

		swipeRefreshLayout.setColorSchemeColors(getResources().getColor(android.R.color.holo_blue_bright),
				getResources().getColor(android.R.color.holo_green_dark),
				getResources().getColor(android.R.color.holo_orange_dark),

				getResources().getColor(android.R.color.holo_red_dark));


		webView.setWebChromeClient(new WebChromeClient() {
			public void onProgressChanged(WebView view, int progress) {
				progressBar.setProgress(progress);

				if (progress == 100) {
					progressBar.setVisibility(View.GONE);

				} else {
					progressBar.setVisibility(View.VISIBLE);

				}
			}

			public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
				// callback.invoke(String origin, boolean allow, boolean remember);
				callback.invoke(origin, true, false);

			}

		});
		webView.setWebViewClient(new WebViewClient() {

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				view.loadUrl(url);
				return true;
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				Toast.makeText(getApplicationContext(), "Error - Pull down To Refress", Toast.LENGTH_SHORT).show();
				webView.loadUrl("file:///android_asset/no/index.html");

				

				//swipeToRefress
				swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
					@Override
					public void onRefresh() {

						swipeRefreshLayout.setRefreshing(true);
						new Handler().postDelayed(new Runnable() {
							@Override
							public void run() {
								swipeRefreshLayout.setRefreshing(false);
								swipeRefreshLayout.setEnabled(false);
								webView.loadUrl(URL);

							}
						}, 3000);
					}
				});

			}

		});

		if (!hasPermissions(MainActivity.this, PERMISSIONS)) {

			ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS, 1);
		}

	/*	if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			notification = new Notification.Builder(this).setSmallIcon(R.drawable.noti).setSound(notificationsound)
					.setVibrate(new long[] { 500 })

					.setContentTitle("tittel").setContentText("This is a notification for you").setChannelId(CHANNEL_ID)
					.build();
			nm.createNotificationChannel(
					new NotificationChannel(CHANNEL_ID, "omg", NotificationManager.IMPORTANCE_HIGH));
		} else {
			notification = new Notification.Builder(this).setSmallIcon(R.drawable.noti).setSound(notificationsound)
					.setVibrate(vibe).setContentTitle("tittel").setContentText("This is a notification for you")
					.build();
		}

		nm.notify(NOTIFICATION_ID, notification);   */

		webView.loadUrl(URL);

	}
	//onCreate End

	public class WebAppInterface {
		Context mContext;
		private Context my_context;

		/** Instantiate the interface and set the context */
		WebAppInterface(Context c) {
			mContext = c;
			my_context = getApplicationContext();
		}

		// -------------------------------- SHOW TOAST ---------------------------------------
		@JavascriptInterface
		public void showToast() {
			Toast.makeText(my_context, "hi", Toast.LENGTH_SHORT).show();
		}
		// -------------------------------- SHOW TOAST ---------------------------------------
		@JavascriptInterface
		public void changeColor() {
			swipeRefreshLayout.setEnabled(true);
			//Toast.makeText(my_context, "hi", Toast.LENGTH_SHORT).show();
			getWindow().setStatusBarColor(ContextCompat.getColor(my_context, R.color.cyon)); //status bar or the time bar at the top (see example image1)
			
			getWindow().setNavigationBarColor(ContextCompat.getColor(my_context, R.color.white)); // Navigation bar the soft bottom of some phones like nexus and some Samsung note series  (see example image2)
		}
		// -------------------------------- SHOW TOAST ---------------------------------------
		@JavascriptInterface
		public void resetColor() {
			swipeRefreshLayout.setEnabled(true);
			//Toast.makeText(my_context, "hi", Toast.LENGTH_SHORT).show();
			getWindow().setStatusBarColor(ContextCompat.getColor(my_context, R.color.fav)); //status bar or the time bar at the top (see example image1)
			
			getWindow().setNavigationBarColor(ContextCompat.getColor(my_context, R.color.cyon)); // Navigation bar the soft bottom of some phones like nexus and some Samsung note series  (see example image2)
		}
		@JavascriptInterface
		public void mapPage() {
			swipeRefreshLayout.setEnabled(false);
			
			//Toast.makeText(my_context, "hi", Toast.LENGTH_SHORT).show();
			getWindow().setStatusBarColor(ContextCompat.getColor(my_context, R.color.fav)); //status bar or the time bar at the top (see example image1)
			
			getWindow().setNavigationBarColor(ContextCompat.getColor(my_context, R.color.cyon)); // Navigation bar the soft bottom of some phones like nexus and some Samsung note series  (see example image2)
		}

		// -------------------------------- START VIBRATE MP3 ---------------------------------------
		@JavascriptInterface
		public void vibrate(int milliseconds) {
			Vibrator v = (Vibrator) my_context.getSystemService(Context.VIBRATOR_SERVICE);
			// Vibrate for 500 milliseconds
			v.vibrate(milliseconds);
		}

		// -------------------------------- CREATE NOTIFICATION ---------------------------------------
		@JavascriptInterface
		public void newNotification(String Name, String Massage) {
			nm = (NotificationManager) my_context.getSystemService(Context.NOTIFICATION_SERVICE);

			if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
				notification = new Notification.Builder(my_context).setSmallIcon(R.drawable.noti)
						.setSound(notificationsound).setVibrate(vibe).setContentTitle(Massage)
						.setContentText(Name).setChannelId(CHANNEL_ID).build();
				nm.createNotificationChannel(
						new NotificationChannel(CHANNEL_ID, "omg", NotificationManager.IMPORTANCE_HIGH));
			} else {
				notification = new Notification.Builder(my_context).setSmallIcon(R.drawable.noti)
						.setSound(notificationsound).setVibrate(vibe).setContentTitle(Massage)
						.setContentText(Name).build();
			}

			nm.notify(NOTIFICATION_ID, notification);

		}
	}

	private boolean hasPermissions(Context context, String... PERMISSIONS) {

		if (context != null && PERMISSIONS != null) {

			for (String permission : PERMISSIONS) {

				if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
					return false;
				}
			}
		}

		return true;
	}

	private void requestRuntimePermission() {

		if (ActivityCompat.checkSelfPermission(this,
				PERMISSION_ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
			Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();

		} else if (ActivityCompat.shouldShowRequestPermissionRationale(this, PERMISSION_ACCESS_FINE_LOCATION)) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage("Location Permission Required").setTitle("Permission Required").setCancelable(false)
					.setPositiveButton("Ok", (dialog, which) -> {

						ActivityCompat.requestPermissions(MainActivity.this,
								new String[] { PERMISSION_ACCESS_FINE_LOCATION }, PERMISSION_REQ_CODE);
						dialog.dismiss();

					}).setNegativeButton("Cancel", ((dialog, which) -> dialog.dismiss()));
			builder.show();
		} else {
			ActivityCompat.requestPermissions(this, new String[] { PERMISSION_ACCESS_FINE_LOCATION },
					PERMISSION_REQ_CODE);
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
			@NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);

		if (requestCode == 1) {

			if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
				Toast.makeText(this, "Storage Permission is granted", Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(this, "Storage Permission is denied", Toast.LENGTH_SHORT).show();
			}

			if (grantResults[1] == PackageManager.PERMISSION_GRANTED) {
				Toast.makeText(this, "Location Permission is granted", Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(this, "Location Permission is denied", Toast.LENGTH_SHORT).show();
				requestRuntimePermission();
			}

			if (grantResults[2] == PackageManager.PERMISSION_GRANTED) {
				Toast.makeText(this, "Camera Permission is granted", Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(this, "Camera Permission is denied", Toast.LENGTH_SHORT).show();
			}

		}
		if (requestCode == PERMISSION_REQ_CODE) {
			if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
				Toast.makeText(this, "Permission Granted ok", Toast.LENGTH_SHORT).show();
			} else if (!ActivityCompat.shouldShowRequestPermissionRationale(this, PERMISSION_ACCESS_FINE_LOCATION)) {
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder.setMessage("this featire unavaliabe beacuse you denied permission")
						.setTitle("Permission Requers").setCancelable(false)
						.setNegativeButton("cancel", ((dialog, which) -> dialog.dismiss()))
						.setPositiveButton("settings", (dialog, which) -> {
							Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
							Uri uri = Uri.fromParts("package", getPackageName(), null);
							intent.setData(uri);
							startActivity(intent);
							dialog.dismiss();
						});
				builder.show();
			} else {
				requestRuntimePermission();
			}
		}

	}

	@Override
	public void onBackPressed() {
		//if user presses the back button do this
		if (webView.isFocused() && webView.canGoBack()) {
			//check if in webview and the user can go back
			webView.goBack();
			//go back in webview
		} else {
			//do this if the webview cannot go back any further

			new AlertDialog.Builder(this)
					//alert the person knowing they are about to close
					.setTitle("EXIT").setMessage("Are you sure. You want to close this app?")
					.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							finish();
						}
					}).setNegativeButton("No", null).show();
		}

	}
}